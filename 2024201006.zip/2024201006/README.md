Prerequisite:
	access.log and power_levels.txt file should be present in the same directory where the shell script is present.
Execution:
	Question 1:
		
		Type the command to run the shell file:
		
			./2024201006_q1.sh
			
	
	Question 2:
		
		Type the command to run the shell file:
		
			./2024201006_q2.sh
